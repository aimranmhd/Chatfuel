# Chatfuel json api 

This page is dedicated to those who love to play arround with Chatfuel.
Here you can find some of my work.

Developing and maintaining this page takes a lot of time.
I hope it saved some of your time. If yes, then you might consider to donate a small amount!

<a href="https://www.paypal.me/mohdaziri/5usd">[Donate $5]</a><br>
<a href="https://www.paypal.me/mohdaziri/10usd">[Donate $10]</a><br>
<a href="https://www.paypal.me/mohdaziri/20usd">[Donate $20]</a><br>
